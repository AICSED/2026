CONTENTS OF FOLDER
Updated: 5 March 2026

Instructions for use of these files are below the list of files.

FILES:

    AREADME.txt
        This file

    main.tex
        latex source file which can be copied and edited to produce
        your file for submission. It is also used to produce the
        guidelines PDF file, below.

    turing.jpg
    turing.ps
        Two image files for use in the template latex file, producing
        the same image.
        The .ps file is used by the 'latex' command.
        The .jpg file is used by the 'pdflatex' command.

        The appropriate image file is invoked by this command in the
        latex source file:

            \centerline{\includegraphics[height=3cm]{turing}}

    aisb.bib
        Samble bibtex input file used to produce citations and the
        bibliography at the end of the latex output file (whether
        of type .pdf, .dvi or .ps)

        This is invoked by bibliography command at the end of the
        latex input file:

            \bibliography{aisb}

        Look at aisb.bib to see how to format your bibliography
        entries if you are not familiar with bibtex.

    turing2012.cls

        This latex class file is invoked in your latex input file by
        the line at the top of the file:

            \documentclass{turing2012}

    AISB.bst
        This is the bibliography style file used by the 'bibtex'
        command to determine the format for the bibliography entries
        and citations.
        After the 'latex' or 'pdflatex' command is run, the
        behaviour of the 'bibtex' command depends on this
        instruction on line 17 in the latex input file, which
        assumes the '.bst' suffix:

            \bibliographystyle{AISB}

    AICSED2026.pdf
        This is both a file giving instructions for use of the
        turing2012 latex style files and also a sample of the result. 



Written by Aaron Sloman, 13 Dec 2009, http://www.cs.bham.ac.uk/~axs
Last changed by Manfred Kerber, 8 Apr 2012, http://www.cs.bham.ac.uk/~mmk
Last changed for the AICSED 2026 symposium in March 2026.

